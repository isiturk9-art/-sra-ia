# İSRA AI iPhone PWA v0.3

Bu paket, yalnızca iPhone ile ilerleyebilmek için Safari'de çalışan ve ana ekrana eklenebilen bir web uygulaması prototipidir.

## İçindekiler
- `web/`: iPhone uyumlu PWA arayüzü, sesli okuma, desteklenen tarayıcılarda mikrofonla dikte.
- `backend/`: OpenAI API anahtarını sunucuda tutan FastAPI servisi.
- API anahtarını asla `web/` dosyalarına veya iPhone ekranına koymayın.

## Şu anki işlevler
- Türkçe sohbet arayüzü
- Son konuşmaları cihazın yerel tarayıcı hafızasında tutma
- Tarayıcı destekliyorsa Türkçe konuşmayı yazıya çevirme
- Cevapları cihazın ses motoruyla sesli okuma
- Sunucu adresi ayarlama ve `/health` bağlantı testi
- Çocuk/yetişkin hitap modu (çocuk modu güvenlik filtresi temel düzeydedir)

Web araması, sürekli arka plan dinleme, telefon araması/SMS gönderme ve akıllı ev kontrolü henüz etkin değildir.

## iPhone ile kurulum yaklaşımı
Bu ZIP tek başına internette yayınlanmış uygulama değildir. iPhone'dan Safari ile kullanmak için `web/` klasörü HTTPS destekleyen bir statik hosting servisine, `backend/` klasörü de Python destekleyen bir sunucuya dağıtılmalıdır.

### 1) Backend'i yayınlama
1. ZIP'i iPhone'un Dosyalar uygulamasında aç.
2. `backend` klasörünü bir GitHub deposuna yükle (GitHub mobil web sitesi üzerinden dosya yükleme kullanılabilir).
3. Render gibi Python web servisinde bu depoyu bağla.
4. Build command: `pip install -r requirements.txt`
5. Start command: `uvicorn server:app --host 0.0.0.0 --port $PORT`
6. Root directory: `backend`
7. Sunucu Environment bölümünde `OPENAI_API_KEY` gizli değişkenini ekle.
8. Web uygulamasını yayınladıktan sonra `ISRA_ALLOWED_ORIGINS` değerine web uygulamasının tam HTTPS adresini gir. Değişiklik sonrası backend'i yeniden dağıt.
9. Backend adresinin sonuna `/health` ekleyerek kontrol et. `{"status":"ok"...}` yanıtı beklenir.

### 2) Web uygulamasını yayınlama
1. `web` klasörünün içeriğini HTTPS statik hosting servisine yükle (ör. Netlify veya Cloudflare Pages).
2. Yayınlanan HTTPS adresini iPhone Safari'de aç.
3. İSRA içindeki Ayarlar bölümüne backend HTTPS adresini gir ve Kaydet'e bas.
4. Bağlantıyı dene ile kontrol et.

### 3) iPhone ana ekranına ekleme
Safari'de yayınlanan İSRA adresini aç > Paylaş > Ana Ekrana Ekle > Ekle.

## iPhone / Safari notları
- Mikrofonla konuşmayı yazıya çevirme Safari/iOS sürümüne göre desteklenmeyebilir; bu durumda klavyenin dikte özelliği veya yazı girişi kullanılabilir.
- Sesli yanıt iOS ses motoruna bağlıdır.
- PWA, iOS'ta uygulama kapalıyken sürekli mikrofon dinleyemez.
- Gerçek iOS uygulaması ve gelişmiş Siri entegrasyonu için ileride Apple geliştirme araçları gerekir.

## Güvenlik ve maliyet
- OpenAI anahtarını yalnızca backend ortam değişkeni olarak saklayın.
- Bu prototipte kimlik doğrulama ve kullanıcı başına kota henüz yoktur; kişisel deneme dışında herkese açmayın.
- Sunucu istek limiti IP bazlı basit korumadır; üretim için kullanıcı kimliği, kota, log politikası ve kötüye kullanım koruması eklenmelidir.
- Konuşma geçmişi bu prototipte cihazdaki `localStorage` alanında saklanır. Paylaşılan cihazlarda geçmişi temizleyin.

## Sonraki geliştirme adımları
1. Kullanıcı hesabı ve güvenli oturum
2. Kalıcı, kullanıcı kontrollü hafıza
3. Web araması ve kaynak gösterme
4. İzinli takvim/e-posta bağlantıları
5. Siri Kestirmeleri ve iOS entegrasyonları
6. Akıllı ev bağlantıları
