import os, time
from collections import defaultdict, deque
from threading import Lock
from typing import Literal
from fastapi import FastAPI, HTTPException, Request
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field
from openai import OpenAI

api_key = os.getenv("OPENAI_API_KEY")
if not api_key:
    raise RuntimeError("OPENAI_API_KEY ortam değişkeni tanımlanmalı.")
client = OpenAI(api_key=api_key, timeout=45.0, max_retries=2)
model = os.getenv("OPENAI_MODEL", "gpt-4.1-mini")
app = FastAPI(title="ISRA AI API", version="0.3.0")
origins = [x.strip() for x in os.getenv("ISRA_ALLOWED_ORIGINS", "").split(",") if x.strip()]
if origins:
    app.add_middleware(CORSMiddleware, allow_origins=origins, allow_credentials=False,
                       allow_methods=["GET", "POST"], allow_headers=["Content-Type"])

class HistoryMessage(BaseModel):
    role: Literal["user", "assistant"]
    content: str = Field(min_length=1, max_length=12000)
class AskRequest(BaseModel):
    message: str = Field(min_length=1, max_length=12000)
    history: list[HistoryMessage] = Field(default_factory=list, max_length=20)
    voice: Literal["Kadın", "Erkek", "Çocuk"] = "Kadın"
    age_group: Literal["adult", "child"] = "adult"

_requests = defaultdict(deque); lock = Lock()
def limit(req: Request):
    ip = req.client.host if req.client else "unknown"; now = time.monotonic()
    with lock:
        q = _requests[ip]
        while q and now-q[0] > 60: q.popleft()
        if len(q) >= 30: raise HTTPException(429, "Çok fazla istek. Biraz bekle.")
        q.append(now)

@app.get("/health")
def health(): return {"status":"ok","assistant":"ISRA","version":"0.3.0"}

@app.post("/ask")
def ask(body: AskRequest, request: Request):
    limit(request); msg = body.message.strip()
    if not msg: raise HTTPException(400, "Mesaj boş olamaz.")
    instructions = """Sen İSRA adlı Türkçe konuşan kişisel yapay zekâ asistanısın.
Nazik, açık, dikkatli ve çözüm odaklı ol. Bilmediğin veya doğrulayamadığın
bilgileri kesinmiş gibi sunma. Bu sürümde web araması ve telefon/akıllı ev
kontrolü etkin değildir; bunları yapmış gibi davranma. Kullanıcı adına gerçek
dünya eylemi yaptığını iddia etme. Hassas bilgi, şifre veya API anahtarı isteme.
Gerekli olduğunda kullanıcıdan izin ve doğrulama gerektiğini belirt."""
    if body.age_group == "child":
        instructions += """ Çocuk modundasın: kısa, sıcak ve yaşa uygun konuş.
Tehlikeli yönergeler verme; adres, telefon, okul veya şifre isteme."""
    history = [{"role":m.role,"content":m.content.strip()} for m in body.history[-12:] if m.content.strip()]
    history.append({"role":"user","content":msg})
    try:
        result = client.responses.create(model=model, instructions=instructions, input=history)
        return {"assistant":"ISRA","answer":result.output_text,"voice":body.voice,
                "age_group":body.age_group,"context_messages":len(history)-1}
    except Exception as exc:
        raise HTTPException(502,"Yapay zekâ servisine şu anda ulaşılamıyor.") from exc
