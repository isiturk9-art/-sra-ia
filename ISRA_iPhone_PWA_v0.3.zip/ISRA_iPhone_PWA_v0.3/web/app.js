const $ = id => document.getElementById(id);
const chat = $("chat"), input = $("message");
let history = JSON.parse(localStorage.getItem("isra_history") || "[]");
let speakOn = true, busy = false, recognition = null;
const savedUrl = localStorage.getItem("isra_api_url") || "";
$("apiUrl").value = savedUrl;
$("voice").value = localStorage.getItem("isra_voice") || "Kadın";
$("age").value = localStorage.getItem("isra_age") || "adult";
function addBubble(role, text, save=true) {
  const div = document.createElement("div"); div.className = "bubble " + role;
  const who = document.createElement("div"); who.className = "who"; who.textContent = role === "user" ? "SEN" : "İSRA";
  const body = document.createElement("div"); body.textContent = text;
  div.append(who, body); chat.append(div); chat.scrollTop = chat.scrollHeight;
  if(save){ history.push({role: role === "user" ? "user" : "assistant", content:text}); history = history.slice(-24); localStorage.setItem("isra_history", JSON.stringify(history)); }
  $("hero").style.display = "none";
}
function say(text) {
  if (!speakOn || !("speechSynthesis" in window)) return;
  speechSynthesis.cancel();
  const utter = new SpeechSynthesisUtterance(text); utter.lang = "tr-TR"; utter.rate = 1; utter.pitch = 1;
  const voices = speechSynthesis.getVoices(); const tr = voices.find(v => v.lang.toLowerCase().startsWith("tr"));
  if(tr) utter.voice = tr; speechSynthesis.speak(utter);
}
async function sendMessage(text) {
  text = (text || input.value).trim(); if(!text || busy) return;
  input.value = ""; input.style.height = "auto"; addBubble("user", text); busy = true; $("send").disabled = true;
  const url = localStorage.getItem("isra_api_url");
  if(!url) {
    const demo = "Şu anda demo modundayım; gerçek yapay zekâ yanıtları için Ayarlar bölümüne güvenli İSRA sunucusunun HTTPS adresi eklenmeli. Mesajını aldım: “" + text + "”";
    addBubble("assistant", demo); say(demo); $("status").textContent = "Demo modu"; busy = false; $("send").disabled = false; return;
  }
  const waiting = document.createElement("div"); waiting.className="bubble assistant"; waiting.textContent="İSRA düşünüyor…"; chat.append(waiting);
  try {
    const res = await fetch(url.replace(/\/$/,"") + "/ask", {
      method:"POST", headers:{"Content-Type":"application/json"},
      body:JSON.stringify({message:text, history:history.slice(0,-1).slice(-12), voice:$("voice").value, age_group:$("age").value})
    });
    const data = await res.json(); if(!res.ok) throw new Error(data.detail || "Sunucu hatası");
    waiting.remove(); addBubble("assistant", data.answer); say(data.answer); $("status").textContent="Bağlı";
  } catch(e) { waiting.remove(); addBubble("assistant","Sunucuya bağlanamadım. Adresi ve internet bağlantını kontrol et. ("+e.message+")"); $("status").textContent="Bağlantı yok"; }
  finally {busy=false; $("send").disabled=false;}
}
$("send").addEventListener("click",()=>sendMessage());
input.addEventListener("keydown",e=>{if(e.key==="Enter"&&!e.shiftKey){e.preventDefault();sendMessage();}});
input.addEventListener("input",()=>{input.style.height="auto";input.style.height=Math.min(input.scrollHeight,110)+"px";});
document.querySelectorAll("[data-prompt]").forEach(b=>b.addEventListener("click",()=>sendMessage(b.dataset.prompt)));
$("settings").onclick=()=>{$("panel").classList.add("open");};
$("close").onclick=()=>$("panel").classList.remove("open");
$("save").onclick=()=>{localStorage.setItem("isra_api_url",$("apiUrl").value.trim());localStorage.setItem("isra_voice",$("voice").value);localStorage.setItem("isra_age",$("age").value);$("settingsMsg").textContent="Ayarlar bu cihazda kaydedildi.";};
$("test").onclick=async()=>{const u=$("apiUrl").value.trim().replace(/\/$/,"");if(!u){$("settingsMsg").textContent="Önce sunucu adresini gir.";return;}try{const r=await fetch(u+"/health");const d=await r.json();$("settingsMsg").textContent=r.ok?"Bağlantı başarılı · "+d.assistant+" v"+d.version:"Sunucu yanıt verdi ama sağlık kontrolü başarısız.";}catch(e){$("settingsMsg").textContent="Bağlantı kurulamadı. HTTPS adresini ve sunucuyu kontrol et.";}};
$("clear").onclick=()=>{if(confirm("Bu cihazdaki İSRA konuşma geçmişi silinsin mi?")){history=[];localStorage.removeItem("isra_history");chat.innerHTML="";$("hero").style.display="block";$("settingsMsg").textContent="Konuşma geçmişi silindi.";}}
$("speakToggle").onclick=()=>{speakOn=!speakOn;$("speakToggle").textContent=speakOn?"🔊 Sesli yanıt açık":"🔇 Sesli yanıt kapalı";if(!speakOn&&"speechSynthesis"in window)speechSynthesis.cancel();};
$("mic").onclick=()=>{
  const SR=window.SpeechRecognition||window.webkitSpeechRecognition;
  if(!SR){$("voiceState").textContent="Bu Safari sürümünde ses tanıma desteklenmiyor. Yazabilirsin.";return;}
  if(recognition){recognition.stop();recognition=null;return;}
  recognition=new SR();recognition.lang="tr-TR";recognition.interimResults=false;recognition.maxAlternatives=1;
  recognition.onstart=()=>{$("voiceState").textContent="Dinliyorum…";$("mic").textContent="■";};
  recognition.onresult=e=>{input.value=e.results[0][0].transcript;$("voiceState").textContent="Sesin yazıya dönüştürüldü.";sendMessage();};
  recognition.onerror=e=>{$("voiceState").textContent="Mikrofon hatası: "+e.error;};
  recognition.onend=()=>{$("mic").textContent="🎙";recognition=null;};
  try{recognition.start();}catch(e){$("voiceState").textContent="Mikrofon başlatılamadı.";}
};
if("serviceWorker" in navigator && location.protocol.startsWith("http")) navigator.serviceWorker.register("./sw.js").catch(()=>{});
if(history.length){$("hero").style.display="none";history.forEach(m=>addBubble(m.role==="user"?"user":"assistant",m.content,false));}
